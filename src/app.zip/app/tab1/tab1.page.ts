import { Component } from '@angular/core';
import { CommonModule } from '@angular/common'; // <-- Necesario para [ngClass]
import { FormsModule } from '@angular/forms'; // <-- Necesario para [(ngModel)]
import { IonHeader, IonToolbar, IonTitle, IonContent } from '@ionic/angular';

// Si tu proyecto traía este componente por defecto y no lo borraste, déjalo. Si te da error, elimínalo.
// import { ExploreContainerComponent } from '../explore-container/explore-container.component';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
  standalone: true, // <-- OBLIGATORIO si vas a usar la propiedad 'imports' aquí adentro
  imports: [
    IonHeader, 
    IonToolbar, 
    IonTitle, 
    IonContent, 
    CommonModule, // Agregado
    FormsModule   // Agregado
    // ExploreContainerComponent 
  ],
})
export class Tab1Page {
  username = '';
  password = '';
  
  userFocus = false;
  passFocus = false;

  isTest = false;
  isTestTwo = false;
  
  isAuthenticating = false;
  isAuthenticatingVisible = false;
  
  hideForm = false;
  isSuccess = false;

  doLogin() {
    this.isTest = true;
    
    setTimeout(() => {
      this.isTestTwo = true;
    }, 300);
    
    setTimeout(() => {
      this.isAuthenticating = true;
      setTimeout(() => this.isAuthenticatingVisible = true, 50);
    }, 500);
    
    setTimeout(() => {
      this.isAuthenticatingVisible = false;
      this.isTestTwo = false;
    }, 2500);
    
    setTimeout(() => {
      this.isTest = false;
      this.hideForm = true;
      this.isAuthenticating = false;
    }, 2800);
    
    setTimeout(() => {
      this.isSuccess = true;
    }, 3200);
  }
}